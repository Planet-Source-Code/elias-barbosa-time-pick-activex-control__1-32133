If you whant to move the file "vbpTimePick.ocx" from this folder, please, move the following files also:

vbpTimePick.oca
vbpTimePick.lib
vbpTimePick.exp